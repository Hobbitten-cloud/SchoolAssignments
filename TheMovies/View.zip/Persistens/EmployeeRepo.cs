﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheMovies.Model;

namespace TheMovies.Persistens
{
    internal class EmployeeRepo
    {
        private List<Employee> employee = new List<Employee>();



    }
}
