﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheMovies.Model;

namespace TheMovies.Persistens
{
    internal class ReservationRepo
    {
        private List<Resevation> resevations = new List<Resevation>();

    }
}
