﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheMovies.Model;

namespace TheMovies.Persistens
{
    public class MovieRepo
    {
        private List<Movie> movie = new List<Movie>();

    }
}
